function convertirADolares() {
    // Obtener el valor ingresado en el campo de pesos
    var cantidadPesos = document.getElementById("pesos").value;
    console.log("cantidad de pesos a convertir "+cantidadPesos);
    var cotizacionDolar=document.getElementById("cotizacionDolares").value;
    console.log("Cotizacion de dolar en pesos uruguayos: "+ cotizacionDolar);
    // Convertir a dólares (1 peso uruguayo equivale aproximadamente a 0.024 dólares)
    var cantidadDolares = cantidadPesos / cotizacionDolar;
    console.log("Cantidad de dolares en total: "+ cantidadDolares);

    // Mostrar el resultado
    alert(cantidadPesos + " pesos uruguayos son aproximadamente " + cantidadDolares.toFixed(2) + " dólares.");
}
