console.log ("Hola Mundo")
var variable=true
console.log(variable)
const constante=5
console.log(constante)
